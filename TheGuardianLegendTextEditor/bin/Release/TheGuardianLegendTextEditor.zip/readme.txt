The Guardian Legend NES ROM Text Editor v.1.0.0.25090
Programmed by: Shawn M. Crawford [sleepy] October 13th, 2016 in C#
---------------------------------------------------------

Features:
	* edit every line of text in the game
	* used with "Guardian Legend, The (U).nes" headered ROM

Requires:
	* Target Framework: .NET 4.5

Usage:
	*Open the Rom (Guardian Legend, The (U).nes), change text, click update, make sure you have a backup in case something breaks.
	*This is first release so it will probably have bugs, feel free to email bugs to sleepy3d@gmail.com

Valid Characters:
0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz;,-?�".`'^

Note the hat (^) represents the fancier looking "M".

1.0.0.25090 October 13th, 2016
---------------------------------------------------------
-initial release



